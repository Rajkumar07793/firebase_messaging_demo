package com.example.firebase_messaging_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
