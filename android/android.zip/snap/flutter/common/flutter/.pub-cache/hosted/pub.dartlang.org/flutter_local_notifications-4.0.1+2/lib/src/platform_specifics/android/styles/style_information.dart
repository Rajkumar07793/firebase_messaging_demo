/// Abstract class for defining an Android notification style
abstract class StyleInformation {}
